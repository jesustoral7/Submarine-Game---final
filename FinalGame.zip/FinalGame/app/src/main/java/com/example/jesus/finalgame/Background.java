package com.example.jesus.finalgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;



public class Background
{
    private Bitmap image;
    private int x;
    private int y;
    private int dx;


    public Background(Bitmap res)
    {
        image = res;
        dx = gPanel.MOVEMENTSPEED;
    }
    public void update()
    {
        x += dx;
        if(x < -gPanel.WIDTH)
        {
            x = 0;
        }
    }
    public void draw(Canvas canvas)
    {
        canvas.drawBitmap(image, x, y, null);
        if( x < 0)
        {
            canvas.drawBitmap(image,x + gPanel.WIDTH, y, null);
        }
    }

}
