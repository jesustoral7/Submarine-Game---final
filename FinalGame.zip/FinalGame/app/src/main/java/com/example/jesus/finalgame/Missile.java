package com.example.jesus.finalgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.speech.SpeechRecognizer;
import android.view.animation.*;

import java.util.Random;



public class Missile extends GameObject
{
    private int score;
    private int speed;
    private Random rand = new Random();
    private Animation anim = new Animation();
    private Bitmap spritesheet;
    public Missile(Bitmap res, int x, int y, int w, int h, int s, int frameNum)
    {
        super.x = x;
        super.y = y;
        width = w;
        height = h;
        score = s;

        speed = 7 + (int) (rand.nextDouble()*score/30);

        //capping speed of missiles
        if(speed >=40)
        {
            speed = 40;
        }
        Bitmap[] image = new Bitmap[frameNum];
        spritesheet = res;

        for(int a = 0; a <image.length;a++)
        {
            image[a] = Bitmap.createBitmap(spritesheet, 0, a*height, width, height);

        }

        anim.setFrames(image);
        anim.setDelay(100-speed);

    }
    public void update()
    {
        x -= speed;
        anim.update();
    }
    public void draw(Canvas canvas)
    {
        try
        {
            canvas.drawBitmap(anim.getImage(), x, y, null);
        }catch (Exception e)
        {

        }
    }
    @Override
    public int getWidth()
    {
        //offset slightly ..realistic collisions
        return width - 10;
    }
}
