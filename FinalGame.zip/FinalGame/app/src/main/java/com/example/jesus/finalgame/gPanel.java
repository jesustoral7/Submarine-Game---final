package com.example.jesus.finalgame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Random;

public class gPanel extends SurfaceView implements SurfaceHolder.Callback
{

    private MainThread thread;
    private Background bg;
    public static final int MOVEMENTSPEED = -5;
    public static final int WIDTH = 1024;
    public static final int HEIGHT = 576;
    private Player player;
    private ArrayList<Bubble> bubbly;
    private long bubbleTiming;
    private long missileStart;
    private ArrayList<Missile> missiles;
    private Bottom botborder;
    private Random random = new Random();



    private boolean newGameCreated;


    private Explosion explosives;
    private long startReset;
    private boolean reset;
    private boolean disappear;
    private boolean started;
    private int best;

    public gPanel(Context context)
    {
        super(context);

        //to intercept events
        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);

        setFocusable(true);

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        boolean retry = true;
        int counter = 0;
        while (retry && counter < 1000)
        {
            counter++;
            try {
                thread.setRunning(false);
                thread.join();
                retry = false;
                thread = null;
            }catch(InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
        bg = new Background(BitmapFactory.decodeResource(getResources(), R.drawable.waterbg));
        player = new Player(BitmapFactory.decodeResource(getResources(),R.drawable.submarine), 65, 48, 1);
        bubbly = new ArrayList<Bubble>();
        missiles = new ArrayList<Missile>();

        botborder = new Bottom(BitmapFactory.decodeResource(getResources(), R.drawable.bottomborder));

        missileStart = System.nanoTime();
        bubbleTiming = System.nanoTime();

        thread = new MainThread(getHolder(), this);
        //start loop
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        if(event.getAction()==MotionEvent.ACTION_DOWN)
        {
            if(!player.getPlaying() && newGameCreated && reset)
            {
                player.setPlaying(true);
                player.setUp(true);
            }
            if(player.getPlaying())
            {
                if(!started)
                {
                    started = true;
                }
                    reset = false;
                    player.setUp(true);

            }
            return true;
        }
        if(event.getAction()==MotionEvent.ACTION_UP)
        {
            player.setUp(false);
            return true;
        }
        return super.onTouchEvent(event);
    }
    public void update()
    {
        if(player.getPlaying())
        {


            bg.update();
            player.update();


 //hits bottom
                if(player.getY() >= HEIGHT - 2*botborder.getHeight())
                {
                    player.setPlaying(false);
                }

            //check top border collision

                if(player.getY() <= 30)
                {
                    player.setPlaying(false);
                 }

            //update top border
            //missile timier add
            long missilesElapsed = (System.nanoTime() - missileStart)/1000000;
            if(missilesElapsed > (2000- player.getScore()/4))
            {
                // missile at random start places
                missiles.add(new Missile(BitmapFactory.decodeResource(getResources(),R.drawable.missile),
                        WIDTH+10, (int)(random.nextDouble()*(HEIGHT)),45,15, player.getScore(),13));
                //timer reset
                missileStart = System.nanoTime();
            }
            //loop through every missile and check collision and remove
            for(int i = 0; i<missiles.size();i++)
            {
                //update missile
                missiles.get(i).update();

                if(collision(missiles.get(i),player))
                {
                    missiles.remove(i);
                    player.setPlaying(false);
                    //break;
                }
                //remove missile if it is off the screen
                if(missiles.get(i).getX()<-100)
                {
                    missiles.remove(i);
                    //break;
                }
            }



            //adding the bubbles on the timer
            long elapsed = (System.nanoTime() - bubbleTiming)/1000000;
            if(elapsed > 120)
            {
                bubbly.add(new Bubble(player.getX(), player.getY()+40));
                bubbleTiming = System.nanoTime();
            }
            for(int i = 0; i < bubbly.size();i++)
            {
                bubbly.get(i).update();
                if(bubbly.get(i).getX() < -10)
                {
                    bubbly.remove(i);
                }
            }
        }
        else
        {
            player.resetDY();
            if(!reset)
            {
                newGameCreated = false;
                startReset = System.nanoTime();
                reset = true;
                disappear = true;
                explosives = new Explosion(BitmapFactory.decodeResource(getResources(), R.drawable.explosion), player.getX(), player.getY() - 30, 100, 100, 25);
            }
            explosives.update();
            long resetElapsed = (System.nanoTime()-startReset)/1000000;
            if(resetElapsed > 2500 && !newGameCreated)
            {
                newGame();
            }
        }
    }

    public boolean collision(GameObject a, GameObject b)
    {
        if(Rect.intersects(a.getRectangle(), b.getRectangle()))
        {
            return true;
        }
        return false;
    }
    @Override
    public void draw(Canvas canvas)
    {
        final float scaleFx = (float)getWidth()/WIDTH;
        final float scaleFy = (float)getHeight()/HEIGHT;
        if(canvas!=null)
        {
            final int savedState = canvas.save();

            canvas.scale(scaleFx, scaleFy);
            bg.draw(canvas);
            if(!disappear)
            {
                player.draw(canvas);
            }

            //draw botborder
            botborder.draw(canvas);
            for(Bubble sp: bubbly)
            {
                sp.draw(canvas);
            }

            //draw missiles
            for(Missile m: missiles)
            {
                m.draw(canvas);
            }

            //draw explosion
            if(started)
            {
                explosives.draw(canvas);
            }
            drawText(canvas);

            canvas.restoreToCount(savedState);


        }
    }


    public void newGame()
    {
        disappear = false;

        missiles.clear();
        bubbly.clear();

        player.resetDY();
        player.resetScore();
        player.setY(HEIGHT/2);

        if(player.getScore()>best)
        {
            best = player.getScore();

        }

        newGameCreated = true;


    }
    public void drawText(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setTextSize(30);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("DISTANCE: " + (player.getScore() * 3), 10, HEIGHT - 10, paint);
        canvas.drawText("BEST: " + best, WIDTH - 215, HEIGHT - 10, paint);

        if (!player.getPlaying() && newGameCreated && reset) {
            Paint paint1 = new Paint();
            paint1.setTextSize(40);
            paint1.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("PRESS TO START", WIDTH / 2 - 50, HEIGHT / 2, paint1);

            paint1.setTextSize(20);
            canvas.drawText("PRESS AND HOLD TO GO UP", WIDTH / 2 - 50, HEIGHT / 2 + 20, paint1);
            canvas.drawText("RELEASE TO GO DOWN", WIDTH / 2 - 50, HEIGHT / 2 + 40, paint1);
        }
    }
}
