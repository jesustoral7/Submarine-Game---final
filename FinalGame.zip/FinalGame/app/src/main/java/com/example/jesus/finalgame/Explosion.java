package com.example.jesus.finalgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.animation.*;

import static com.example.jesus.finalgame.MainThread.canvas;


public class Explosion
{
    private int x;
    private int y;
    private int width;
    private int height;
    private int row;
    private Animation animation = new Animation();
    private Bitmap spritesheet;

    public Explosion(Bitmap res, int x, int y, int w, int h, int frameNum) {
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;

        Bitmap[] image = new Bitmap[frameNum];
        spritesheet = res;

        for (int m = 0; m < image.length; m++) {
            if (m % 5 == 0 && m > 0) {
                row++;
                image[m] = Bitmap.createBitmap(spritesheet, (m - (5 * row)) * width, row * height, width, height);
            }
            animation.setFrames(image);
            animation.setDelay(10);
        }
    }


    public void draw(Canvas canvas)
    {
if(!animation.playeddOnce())
{
    canvas.drawBitmap(animation.getImage(), x, y, null);
}
    }
    public void update()
    {
        if(!animation.playeddOnce())
        {
            animation.update();
        }
    }
    public int getHeight()
    {
        return height;
    }
}


