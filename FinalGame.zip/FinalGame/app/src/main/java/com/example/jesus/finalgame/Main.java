package com.example.jesus.finalgame;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.media.MediaPlayer;

import static android.view.Window.FEATURE_NO_TITLE;

public class Main extends Activity {

    MediaPlayer bgmusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(FEATURE_NO_TITLE);

        //set to full screen.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(new gPanel(this));

        bgmusic = MediaPlayer.create(Main.this, R.raw.bgmusic);
        bgmusic.setLooping(true);
        bgmusic.start();
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        bgmusic.release();
        finish();
    }
}
